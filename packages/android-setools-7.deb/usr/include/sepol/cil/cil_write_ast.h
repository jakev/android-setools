#ifndef CIL_WRITE_H_
#define CIL_WRITE_H_

#include <cil/cil.h>

int cil_write_ast(struct cil_db *db, const char* path);
#endif /* CIL_WRITE_H_ */
