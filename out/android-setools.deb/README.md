

	sudo apt install swig flex bison python-dev python-setuptools python-networkx
